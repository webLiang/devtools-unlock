/**
 * DevTools Shield — MAIN world 注入
 *
 * 针对 scripts-CbWe9mAN.js 的关键路径：
 * 1. 启动时检测 setInterval/setTimeout/addEventListener.toString() 不含 native code → ca()
 * 2. ca() → sa() 清空 body/documentElement.innerHTML → 100ms 后 location.reload()
 * 3. disable-devtool 轮询 interval=200ms（不是 500）
 * 4. ondevtoolopen → 同上 + history.back / 404 跳转
 */
(function devtoolsShield() {
  'use strict';

  const TAG = '[devtools-shield]';
  if (window.__devtoolsShieldInstalled) {
    return;
  }
  window.__devtoolsShieldInstalled = true;

  const saved = {
    outerWDesc: Object.getOwnPropertyDescriptor(window, 'outerWidth'),
    outerHDesc: Object.getOwnPropertyDescriptor(window, 'outerHeight'),
    fnToString: Function.prototype.toString,
    dateToString: Date.prototype.toString,
    regToString: RegExp.prototype.toString,
    setInterval: window.setInterval,
    setTimeout: window.setTimeout,
    addEventListener: window.EventTarget.prototype.addEventListener,
    locationHrefDesc: Object.getOwnPropertyDescriptor(window.Location.prototype, 'href'),
    locationAssign: window.Location.prototype.assign,
    locationReplace: window.Location.prototype.replace,
    locationReload: window.Location.prototype.reload,
    historyBack: window.history.back,
    historyGo: window.history.go,
    windowOpen: window.open,
    windowClose: window.close,
    consoleLog: console.log,
    consoleTable: console.table,
    consoleClear: console.clear,
    docInnerHTMLDesc: Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML'),
    docInnerTextDesc: Object.getOwnPropertyDescriptor(Element.prototype, 'innerText'),
  };

  const snap = {
    innerW: window.innerWidth,
    innerH: window.innerHeight,
  };

  const BLOCK_URL_RE =
    /theajack\.github\.io\/disable-devtool|disable-devtool\/404\.html/i;

  const NATIVE_MARK = 'native code';

  /** 让包装函数 toString 仍像原生，避免站点启动时的 tamper 检测触发 ca() */
  function mimicNative(fn, ref) {
    const refFn = ref || fn;
    fn.toString = function mimicNativeToString() {
      try {
        return saved.fnToString.call(refFn);
      } catch (e) {
        return 'function () { [' + NATIVE_MARK + '] }';
      }
    };
    return fn;
  }

  /** 是否为 disable-devtool / 反调试相关定时器 */
  function isDevToolTimer(fn, delay) {
    if (typeof fn !== 'function') {
      return false;
    }
    if (delay !== 200 && delay !== 500 && delay !== 100 && delay !== 150 && delay !== 1000) {
      return false;
    }
    let fnText = '';
    try {
      fnText = saved.fnToString.call(fn);
    } catch (e) {
      fnText = '';
    }
    return /isDevToolOpened|ondevtoolopen|onDevToolOpen|DevToolOpen|detector|clearLog|clearDevTool|markDevTool|f3w5S8C|v1i\(|A7u\(|detect\(|native code|WJwgqCmf/i.test(
      fnText
    );
  }

  /** 是否为 ca() 触发的 reload 定时器（100ms） */
  function isReloadTimer(fn, delay) {
    if (delay !== 100 && delay !== 500) {
      return false;
    }
    if (typeof fn !== 'function') {
      return false;
    }
    let fnText = '';
    try {
      fnText = saved.fnToString.call(fn);
    } catch (e) {
      fnText = '';
    }
    return /reload|location|href|v1i|A7u|ca\(|u\(\)/i.test(fnText);
  }

  function isBlockedNavigation(url) {
    if (!url) {
      return false;
    }
    return BLOCK_URL_RE.test(String(url));
  }

  function isRootNode(el) {
    return (
      el === document.documentElement ||
      el === document.body ||
      (el && (el.tagName === 'HTML' || el.tagName === 'BODY'))
    );
  }

  function installViewportMask() {
    Object.defineProperty(window, 'outerWidth', {
      configurable: true,
      get() {
        return snap.innerW;
      },
    });
    Object.defineProperty(window, 'outerHeight', {
      configurable: true,
      get() {
        return snap.innerH;
      },
    });
    window.addEventListener(
      'resize',
      function refreshSnap() {
        snap.innerW = window.innerWidth;
        snap.innerH = window.innerHeight;
      },
      true
    );
  }

  function installConsoleMask() {
    const names = [
      'log', 'warn', 'error', 'info', 'debug', 'trace', 'table', 'clear',
      'dir', 'dirxml', 'group', 'groupCollapsed', 'groupEnd', 'time', 'timeEnd',
      'count', 'assert', 'profile', 'profileEnd',
    ];

    for (let i = 0; i < names.length; i++) {
      const key = names[i];
      if (typeof console[key] !== 'function') {
        console[key] = function noop() {};
      }
      try {
        Object.defineProperty(console, key, {
          configurable: true,
          enumerable: true,
          writable: true,
          value: console[key],
        });
      } catch (e) {
        // ignore
      }
    }
  }

  function installNativeToStringMask() {
    const origFnToString = saved.fnToString;

    Function.prototype.toString = function patchedFnToString() {
      if (this === patchedFnToString) {
        return 'function toString() { [' + NATIVE_MARK + '] }';
      }
      try {
        const out = origFnToString.call(this);
        if (out.indexOf(NATIVE_MARK) !== -1) {
          return out;
        }
        if (/^function\s/.test(out) || /^class\s/.test(out)) {
          return 'function () { [' + NATIVE_MARK + '] }';
        }
        return out;
      } catch (e) {
        return 'function () { [' + NATIVE_MARK + '] }';
      }
    };

    Date.prototype.toString = function patchedDateToString() {
      try {
        return saved.dateToString.call(this);
      } catch (e) {
        return '[object Date]';
      }
    };

    RegExp.prototype.toString = function patchedRegToString() {
      try {
        return saved.regToString.call(this);
      } catch (e) {
        return '/./';
      }
    };
  }

  /** 静默 console 输出，降低 Performance / FuncToString 检测 */
  function installConsoleTimingMask() {
    console.log = function shieldConsoleLog() {};
    console.table = function shieldConsoleTable() {};
    console.clear = function shieldConsoleClear() {};
  }

  function installNavigationGuard() {
    const locProto = window.Location.prototype;

    if (saved.locationHrefDesc && saved.locationHrefDesc.set) {
      Object.defineProperty(locProto, 'href', {
        configurable: true,
        enumerable: true,
        get: saved.locationHrefDesc.get,
        set(value) {
          if (isBlockedNavigation(value)) {
            console.warn(TAG, '拦截 location.href =', value);
            return;
          }
          return saved.locationHrefDesc.set.call(this, value);
        },
      });
    }

    locProto.assign = mimicNative(function shieldAssign(url) {
      if (isBlockedNavigation(url)) {
        console.warn(TAG, '拦截 location.assign', url);
        return;
      }
      return saved.locationAssign.call(this, url);
    }, saved.locationAssign);

    locProto.replace = mimicNative(function shieldReplace(url) {
      if (isBlockedNavigation(url)) {
        console.warn(TAG, '拦截 location.replace', url);
        return;
      }
      return saved.locationReplace.call(this, url);
    }, saved.locationReplace);

    locProto.reload = mimicNative(function shieldReload() {
      console.warn(TAG, '拦截 location.reload()');
    }, saved.locationReload);

    try {
      window.location.reload = locProto.reload;
    } catch (e) {
      // ignore
    }

    window.history.back = mimicNative(function shieldBack() {
      console.warn(TAG, '拦截 history.back()');
    }, saved.historyBack);

    window.history.go = mimicNative(function shieldGo(delta) {
      if (delta === 0 || delta === undefined) {
        console.warn(TAG, '拦截 history.go(0) reload');
        return;
      }
      return saved.historyGo.call(window.history, delta);
    }, saved.historyGo);

    window.open = mimicNative(function shieldOpen(url, target) {
      if (target === '_self' && (!url || url === '')) {
        console.warn(TAG, '拦截 window.open("", "_self")');
        return null;
      }
      if (isBlockedNavigation(url)) {
        console.warn(TAG, '拦截 window.open', url);
        return null;
      }
      return saved.windowOpen.apply(window, arguments);
    }, saved.windowOpen);

    window.close = mimicNative(function shieldClose() {
      console.warn(TAG, '拦截 window.close()');
    }, saved.windowClose);
  }

  /**
   * 拦截 sa() 清空页面：body / documentElement innerHTML = ""
   * 以及 ondevtoolopen 的大段 rewriteHTML
   */
  function installDomGuard() {
    function blockWrite(prop, desc) {
      if (!desc || !desc.set) {
        return;
      }

      Object.defineProperty(Element.prototype, prop, {
        configurable: true,
        enumerable: desc.enumerable,
        get: desc.get,
        set(value) {
          if (typeof value !== 'string') {
            return desc.set.call(this, value);
          }

          if (isRootNode(this) && value.length < 100) {
            console.warn(TAG, '拦截根节点清空', this.tagName || 'ROOT', prop);
            return;
          }

          if (this === document.documentElement && value.length > 200) {
            console.warn(TAG, '拦截 documentElement.' + prop + ' 覆写');
            return;
          }

          return desc.set.call(this, value);
        },
      });
    }

    blockWrite('innerHTML', saved.docInnerHTMLDesc);
    blockWrite('innerText', saved.docInnerTextDesc);
  }

  function installDisableDevtoolApiTrap() {
    const fakeApi = {
      isRunning: true,
      isSuspend: true,
      isDevToolOpened: function () {
        return false;
      },
      version: '0.0.0-shield',
      DetectorType: {},
      md5: function () {
        return '';
      },
    };

    const names = ['DisableDevtool', 'disableDevtool'];
    for (let i = 0; i < names.length; i++) {
      const n = names[i];
      try {
        Object.defineProperty(window, n, {
          configurable: true,
          get() {
            return fakeApi;
          },
          set() {
            console.warn(TAG, '忽略', n, '赋值');
          },
        });
      } catch (e) {
        // ignore
      }
    }
  }

  function installTimerFilters() {
    window.setInterval = mimicNative(function shieldSetInterval(fn, delay) {
      if (isDevToolTimer(fn, delay)) {
        console.warn(TAG, '跳过 disable-devtool setInterval', delay);
        return -1;
      }
      return saved.setInterval.apply(window, arguments);
    }, saved.setInterval);

    window.setTimeout = mimicNative(function shieldSetTimeout(fn, delay) {
      if (isReloadTimer(fn, delay) || isDevToolTimer(fn, delay)) {
        console.warn(TAG, '跳过反调试 setTimeout', delay);
        return -1;
      }
      return saved.setTimeout.apply(window, arguments);
    }, saved.setTimeout);

    EventTarget.prototype.addEventListener = mimicNative(function shieldAddEventListener(type, listener, options) {
      return saved.addEventListener.call(this, type, listener, options);
    }, saved.addEventListener);
  }

  installViewportMask();
  installConsoleMask();
  installNativeToStringMask();
  installConsoleTimingMask();
  installNavigationGuard();
  installDomGuard();
  installDisableDevtoolApiTrap();
  installTimerFilters();

  window.__devtoolsShieldOff = function __devtoolsShieldOff() {
    if (saved.outerWDesc) {
      Object.defineProperty(window, 'outerWidth', saved.outerWDesc);
    }
    if (saved.outerHDesc) {
      Object.defineProperty(window, 'outerHeight', saved.outerHDesc);
    }

    Function.prototype.toString = saved.fnToString;
    Date.prototype.toString = saved.dateToString;
    RegExp.prototype.toString = saved.regToString;
    console.log = saved.consoleLog;
    console.table = saved.consoleTable;
    console.clear = saved.consoleClear;
    window.setInterval = saved.setInterval;
    window.setTimeout = saved.setTimeout;
    EventTarget.prototype.addEventListener = saved.addEventListener;
    window.open = saved.windowOpen;
    window.close = saved.windowClose;
    window.history.back = saved.historyBack;
    window.history.go = saved.historyGo;

    if (saved.locationHrefDesc) {
      Object.defineProperty(window.Location.prototype, 'href', saved.locationHrefDesc);
    }
    window.Location.prototype.assign = saved.locationAssign;
    window.Location.prototype.replace = saved.locationReplace;
    window.Location.prototype.reload = saved.locationReload;

    delete window.__devtoolsShieldInstalled;
    delete window.__devtoolsShieldOff;
    console.log(TAG, '已卸载');
  };

  console.log(TAG, '扩展已注入 — 可正常打开 DevTools');
})();

const toggle = document.getElementById('toggle');
const statusEl = document.getElementById('status');

/** 更新界面状态文案 */
function renderStatus(enabled) {
  toggle.checked = enabled;
  statusEl.textContent = enabled ? '防护已开启' : '防护已关闭';
  statusEl.classList.toggle('off', !enabled);
}

/** 从 background 读取当前开关 */
function loadStatus() {
  chrome.runtime.sendMessage({ type: 'getStatus' }, (res) => {
    if (chrome.runtime.lastError) {
      statusEl.textContent = '读取状态失败';
      statusEl.classList.add('off');
      return;
    }
    renderStatus(res && res.enabled !== false);
  });
}

toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  chrome.runtime.sendMessage({ type: 'setEnabled', enabled }, (res) => {
    if (chrome.runtime.lastError || !res || !res.ok) {
      loadStatus();
      return;
    }
    renderStatus(enabled);
  });
});

loadStatus();

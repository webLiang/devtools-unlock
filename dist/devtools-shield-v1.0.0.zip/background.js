/**
 * MV3 Service Worker：按开关状态注册 / 注销 MAIN world 注入脚本。
 * 必须在 document_start + MAIN world 执行，才能早于页面业务脚本。
 */
const SCRIPT_ID = 'devtools-shield-main';

const scriptConfig = {
  id: SCRIPT_ID,
  matches: ['<all_urls>'],
  // 不在 Chrome 网上应用店等系统页注入，减少无关权限触达
  excludeMatches: [
    '*://chrome.google.com/*',
    '*://chromewebstore.google.com/*',
    '*://microsoftedge.microsoft.com/addons/*',
  ],
  js: ['shield.js'],
  runAt: 'document_start',
  world: 'MAIN',
  allFrames: true,
};

/** 读取扩展开关，默认开启 */
async function isEnabled() {
  const data = await chrome.storage.local.get({ enabled: true });
  return data.enabled !== false;
}

/** 注册 MAIN world 内容脚本 */
async function registerShield() {
  try {
    await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] });
  } catch (e) {
    // 首次安装时可能尚未注册，忽略
  }
  await chrome.scripting.registerContentScripts([scriptConfig]);
}

/** 注销内容脚本 */
async function unregisterShield() {
  try {
    await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] });
  } catch (e) {
    // ignore
  }
}

/** 根据 storage 同步注册状态 */
async function syncRegistration() {
  if (await isEnabled()) {
    await registerShield();
  } else {
    await unregisterShield();
  }
}

chrome.runtime.onInstalled.addListener(() => {
  syncRegistration();
});

chrome.runtime.onStartup.addListener(() => {
  syncRegistration();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.enabled) {
    syncRegistration();
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'getStatus') {
    isEnabled().then((enabled) => sendResponse({ enabled }));
    return true;
  }
  if (message.type === 'setEnabled') {
    chrome.storage.local.set({ enabled: !!message.enabled }).then(() => {
      syncRegistration().then(() => sendResponse({ ok: true }));
    });
    return true;
  }
});
